import React from 'react';
import { Calculator } from './components/Calculator';

export default function App() {
  return (
    <div className="min-h-screen w-full bg-slate-950 text-slate-100 flex flex-col justify-between transition-colors duration-500 selection:bg-indigo-500/30 selection:text-white">
      {/* Top clean header */}
      <header className="pt-8 px-4 text-center">
        <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight bg-gradient-to-r from-indigo-200 via-white to-purple-200 bg-clip-text text-transparent">
          Kalkulator Modern
        </h1>
        <p className="text-slate-500 text-xs mt-1.5 font-sans uppercase tracking-widest max-w-xs mx-auto">
          Clean UI & Comfortable Dark Mode
        </p>
      </header>

      {/* Main Container centering the responsive calculator widget */}
      <main className="flex-1 flex items-center justify-center w-full max-w-7xl mx-auto">
        <Calculator />
      </main>

      {/* Aesthetic pairing standard humble footer */}
      <footer className="pb-6 pt-4 text-center text-slate-600 text-xs font-mono select-none">
        &copy; {new Date().getFullYear()} &middot; Kalkulator Modern &middot; Crafted with Precision
      </footer>
    </div>
  );
}
