import { motion } from 'motion/react';
import React from 'react';

export type ButtonType = 'number' | 'operator' | 'action' | 'equals';

interface CalculatorButtonProps {
  id: string;
  value: string;
  label: React.ReactNode;
  type: ButtonType;
  isActive?: boolean;
  onClick: (value: string) => void;
  className?: string;
}

export const CalculatorButton: React.FC<CalculatorButtonProps> = ({
  id,
  value,
  label,
  type,
  isActive = false,
  onClick,
  className = '',
}) => {
  // Map buttons to modern color palettes that are easy on the eyes in dark mode
  let baseStyles = 'flex items-center justify-center font-display rounded-2xl transition-colors text-lg font-medium select-none cursor-pointer relative overflow-hidden focus:outline-none';
  
  // Custom height to ensure excellent touch target scaling on Android (minimum 44px or relative equivalent)
  const mobileHeight = 'h-14 sm:h-16 w-full';

  switch (type) {
    case 'number':
      baseStyles += ' bg-slate-800/60 hover:bg-slate-800 text-slate-100 active:bg-slate-700/60 transition-all';
      break;
    case 'operator':
      baseStyles += isActive
        ? ' bg-indigo-550 border border-indigo-400 text-white shadow-[0_0_15px_rgba(99,102,241,0.5)]'
        : ' bg-indigo-650 hover:bg-indigo-600 active:bg-indigo-700 text-indigo-100 transition-all';
      break;
    case 'action':
      baseStyles += ' bg-slate-700/40 hover:bg-slate-700/70 text-slate-300 active:bg-slate-700 transition-all';
      break;
    case 'equals':
      baseStyles += ' bg-gradient-to-br from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white shadow-lg active:opacity-90 font-bold transition-all';
      break;
  }

  return (
    <motion.button
      id={id}
      type="button"
      whileTap={{ scale: 0.94 }}
      transition={{ type: 'spring', stiffness: 400, damping: 20 }}
      onClick={() => onClick(value)}
      className={`${baseStyles} ${mobileHeight} ${className}`}
    >
      {label}
      {/* Subtle active highlight dot for selected operators */}
      {isActive && (
        <span className="absolute bottom-2 w-1.5 h-1.5 bg-white rounded-full animate-pulse" />
      )}
    </motion.button>
  );
};
