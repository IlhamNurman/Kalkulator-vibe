import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  CalculatorButton, 
  ButtonType 
} from './CalculatorButton';
import { 
  History, 
  Delete, 
  Percent, 
  Check, 
  HelpCircle, 
  RotateCcw,
  Volume2,
  VolumeX
} from 'lucide-react';

interface HistoryItem {
  id: string;
  equation: string;
  result: string;
  timestamp: Date;
}

export const Calculator: React.FC = () => {
  // State for values
  const [currentInput, setCurrentInput] = useState<string>('0');
  const [previousValue, setPreviousValue] = useState<string | null>(null);
  const [activeOperation, setActiveOperation] = useState<string | null>(null);
  const [equation, setEquation] = useState<string>('');
  const [isCalculated, setIsCalculated] = useState<boolean>(false);
  
  // History log
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [showHistory, setShowHistory] = useState<boolean>(false);
  
  // Sound and Tactile settings
  const [soundEnabled, setSoundEnabled] = useState<boolean>(false);
  
  // Ref for the audio context (if user wants clean pop sounds)
  const audioCtxRef = useRef<AudioContext | null>(null);

  // Play a beautiful subtle synthesizer pop sound on interactive tap if enabled
  const playClickSound = useCallback((freq: number = 800, type: OscillatorType = 'sine', duration: number = 0.05) => {
    if (!soundEnabled) return;
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume();
      }
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      osc.type = type;
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      
      // Smooth decay
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      
      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch (e) {
      console.warn("Audio Context error:", e);
    }
  }, [soundEnabled]);

  // Math rounding helper to fix precision issues (like 0.1 + 0.2 = 0.3)
  const formatResult = (num: number): string => {
    if (isNaN(num)) return 'Format Salah';
    if (!isFinite(num)) {
      playClickSound(200, 'sawtooth', 0.15);
      return 'Tidak Terhingga'; // Indonesian for Infinity (div by zero)
    }
    
    const absNum = Math.abs(num);
    // Display very large or very small figures cleanly
    if (absNum > 1e12 || (absNum < 1e-7 && absNum > 0)) {
      return num.toExponential(6);
    }
    
    // Round to maximum 10 decimal digits to filter out floating point inaccuracies
    const roundedNum = Number(num.toFixed(10));
    return String(roundedNum);
  };

  const performCalculation = (first: number, second: number, operator: string): number => {
    switch (operator) {
      case '+': return first + second;
      case '-': return first - second;
      case '×': return first * second;
      case '÷': return second === 0 ? NaN : first / second;
      default: return second;
    }
  };

  const handleNumber = useCallback((num: string) => {
    playClickSound(600, 'sine', 0.03);
    if (isCalculated) {
      setCurrentInput(num === '.' ? '0.' : num);
      setIsCalculated(false);
      return;
    }

    if (num === '.') {
      if (currentInput.includes('.')) return; // Prevent multiple decimal points
      setCurrentInput(currentInput + '.');
    } else {
      if (currentInput === '0') {
        setCurrentInput(num);
      } else {
        // Prevent typing overly long numbers beyond safety limits (15 digits)
        if (currentInput.replace('.', '').length >= 15) return;
        setCurrentInput(currentInput + num);
      }
    }
  }, [currentInput, isCalculated, playClickSound]);

  const handleOperator = useCallback((op: string) => {
    playClickSound(800, 'sine', 0.04);
    const currentValueFloat = parseFloat(currentInput);

    if (activeOperation && !isCalculated && currentInput === '0') {
      // Just swap the active operator if user changes mind without entering value
      setActiveOperation(op);
      setEquation(`${previousValue} ${op} `);
      return;
    }

    if (previousValue === null) {
      setPreviousValue(currentInput);
      setActiveOperation(op);
      setEquation(`${currentInput} ${op} `);
      setCurrentInput('0');
    } else if (activeOperation) {
      // Intermediate calculation
      const prevFloat = parseFloat(previousValue);
      const intermediateResult = performCalculation(prevFloat, currentValueFloat, activeOperation);
      
      const formatted = formatResult(intermediateResult);
      setPreviousValue(formatted);
      setActiveOperation(op);
      setEquation(`${formatted} ${op} `);
      setCurrentInput('0');
    }

    if (isCalculated) {
      setPreviousValue(currentInput);
      setActiveOperation(op);
      setEquation(`${currentInput} ${op} `);
      setIsCalculated(false);
      setCurrentInput('0');
    }
  }, [currentInput, previousValue, activeOperation, isCalculated, playClickSound]);

  const handleEqual = useCallback(() => {
    if (!previousValue || !activeOperation || isCalculated) return;
    
    playClickSound(900, 'sine', 0.06);
    const firstNum = parseFloat(previousValue);
    const secondNum = parseFloat(currentInput);
    
    const finalResult = performCalculation(firstNum, secondNum, activeOperation);
    const formattedResult = formatResult(finalResult);
    
    const fullEquation = `${previousValue} ${activeOperation} ${currentInput} =`;
    
    setEquation(fullEquation);
    setCurrentInput(formattedResult);
    
    // Add to history list if result is valid
    if (formattedResult !== 'Format Salah' && formattedResult !== 'Tidak Terhingga') {
      const newItem: HistoryItem = {
        id: Date.now().toString(),
        equation: `${previousValue} ${activeOperation} ${currentInput}`,
        result: formattedResult,
        timestamp: new Date()
      };
      setHistory(prev => [newItem, ...prev].slice(0, 50)); // Keep last 50 entries
    }

    setPreviousValue(null);
    setActiveOperation(null);
    setIsCalculated(true);
  }, [currentInput, previousValue, activeOperation, isCalculated, playClickSound]);

  const handleClear = useCallback(() => {
    playClickSound(500, 'triangle', 0.1);
    setCurrentInput('0');
    setPreviousValue(null);
    setActiveOperation(null);
    setEquation('');
    setIsCalculated(false);
  }, [playClickSound]);

  const handleBackspace = useCallback(() => {
    playClickSound(400, 'sine', 0.03);
    if (isCalculated) {
      handleClear();
      return;
    }
    if (currentInput.length > 1) {
      setCurrentInput(currentInput.slice(0, -1));
    } else {
      setCurrentInput('0');
    }
  }, [currentInput, isCalculated, handleClear, playClickSound]);

  const handleToggleSign = useCallback(() => {
    playClickSound(700, 'sine', 0.03);
    if (currentInput === '0') return;
    setCurrentInput(currentInput.startsWith('-') ? currentInput.substring(1) : '-' + currentInput);
  }, [currentInput, playClickSound]);

  const handlePercent = useCallback(() => {
    playClickSound(700, 'sine', 0.03);
    const floatVal = parseFloat(currentInput);
    const pctResult = floatVal / 100;
    setCurrentInput(formatResult(pctResult));
    setIsCalculated(true);
  }, [currentInput, playClickSound]);

  // Support Keyboard bindings
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Prevent standard browser overrides if typing in the calculator body
      const activeElement = document.activeElement;
      const isInputFocused = activeElement instanceof HTMLInputElement || activeElement instanceof HTMLTextAreaElement;
      if (isInputFocused) return;

      const key = e.key;

      if (/[0-9]/.test(key)) {
        e.preventDefault();
        handleNumber(key);
      } else if (key === '.') {
        e.preventDefault();
        handleNumber('.');
      } else if (key === '+') {
        e.preventDefault();
        handleOperator('+');
      } else if (key === '-') {
        e.preventDefault();
        handleOperator('-');
      } else if (key === '*' || key === 'x' || key === 'X') {
        e.preventDefault();
        handleOperator('×');
      } else if (key === '/') {
        e.preventDefault();
        handleOperator('÷');
      } else if (key === 'Enter' || key === '=') {
        e.preventDefault();
        handleEqual();
      } else if (key === 'Backspace') {
        e.preventDefault();
        handleBackspace();
      } else if (key === 'Escape' || key === 'c' || key === 'C') {
        e.preventDefault();
        handleClear();
      } else if (key === '%') {
        e.preventDefault();
        handlePercent();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [handleNumber, handleOperator, handleEqual, handleBackspace, handleClear, handlePercent]);

  // Helper to get formatted operator display symbol
  const getOpSymbol = (op: string | null) => {
    if (!op) return '';
    return op;
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[85vh] sm:min-h-[80vh] px-4 py-8">
      
      {/* Outer Shell Wrapper with beautiful soft neon backlight glow */}
      <div className="relative w-full max-w-sm">
        
        {/* Decorative dynamic ambient glow rings */}
        <div className="absolute -inset-1.5 bg-gradient-to-r from-indigo-500 via-purple-600 to-pink-500 rounded-3xl blur opacity-25 group-hover:opacity-40 transition duration-1000 group-hover:duration-200 animate-tilt calculator-glow" />

        {/* The main physical-like Dark-Mode Calculator Body */}
        <div className="relative w-full bg-slate-900 border border-slate-800/80 rounded-3xl overflow-hidden shadow-2xl p-6 flex flex-col gap-5">
          
          {/* Header Controls: Sound Toggle, App title, History Panel Trigger */}
          <div className="flex items-center justify-between text-xs text-slate-400 font-sans tracking-wide">
            
            {/* Left: Brand/Logo Tag with modern minimalist styling */}
            <div className="flex items-center gap-1.5 font-medium">
              <span className="w-2 h-2 rounded-full bg-indigo-500" />
              <span className="font-display font-semibold text-slate-300">CALC</span>
              <span className="text-slate-600">v4.0</span>
            </div>

            {/* Right: Sound toggle and History Toggle panel */}
            <div className="flex items-center gap-2">
              <button 
                id="toggle_sound"
                type="button"
                onClick={() => {
                  setSoundEnabled(!soundEnabled);
                  // Trigger simple initial click to register/initiate AudioCtx if turning on
                  if(!soundEnabled) {
                    try {
                      audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
                      setTimeout(() => playClickSound(700, 'sine', 0.05), 50);
                    } catch(e){}
                  }
                }}
                className={`p-2 rounded-lg transition-colors cursor-pointer relative ${
                  soundEnabled 
                    ? 'text-indigo-400 hover:bg-slate-800/80 bg-slate-800/40' 
                    : 'text-slate-500 hover:bg-slate-800/50'
                }`}
                title="Aktifkan efek suara klik"
              >
                {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              </button>

              <button
                id="toggle_history"
                type="button"
                onClick={() => {
                  playClickSound(500, 'sine', 0.03);
                  setShowHistory(!showHistory);
                }}
                className={`p-2 rounded-lg transition-colors cursor-pointer ${
                  showHistory 
                    ? 'text-indigo-400 bg-indigo-950/40 hover:bg-indigo-950/60' 
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
                title="Riwayat Perhitungan"
              >
                <History className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* OLED Calculator Display Screen */}
          <div className="bg-slate-950/90 border border-slate-800/60 rounded-2xl p-5 flex flex-col justify-between items-end relative overflow-hidden min-h-[110px] sm:min-h-[120px] transition-all duration-300">
            {/* Screen background scanline lines for that ultra-premium glass glow accent */}
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-indigo-900/10 via-transparent to-transparent pointer-events-none" />
            
            {/* Upper Formula Line */}
            <div className="w-full text-right text-indigo-400/80 font-mono text-xs sm:text-sm font-medium tracking-wide h-6 overflow-hidden truncate">
              {equation ? equation : '\u00A0'}
            </div>

            {/* Main Calculated/Inputting Value Line */}
            {/* Dynamically reduces font size if value runs too long to prevent overflowing card boundary */}
            <div className="w-full text-right overflow-x-auto select-all scrollbar-none">
              <span className={`text-white font-display font-medium tracking-wide block leading-none transition-all duration-200 ${
                currentInput.length > 12 
                  ? 'text-2xl' 
                  : currentInput.length > 8 
                    ? 'text-3xl sm:text-4xl' 
                    : 'text-4xl sm:text-5xl'
              }`}>
                {currentInput}
              </span>
            </div>
          </div>

          {/* Interactive Calculator Buttons & History Content Area */}
          <div className="relative min-h-[300px] sm:min-h-[352px]">
            <AnimatePresence mode="wait">
              {!showHistory ? (
                /* Primary Button Grid layout, perfect for Android screen dimensions */
                <motion.div
                  key="calculator-grid"
                  initial={{ opacity: 0, scale: 0.98 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.98 }}
                  transition={{ duration: 0.15 }}
                  className="grid grid-cols-4 gap-3"
                >
                  {/* Row 1 */}
                  <CalculatorButton
                    id="btn_clear"
                    value="C"
                    label={<span className="font-semibold text-rose-400">C</span>}
                    type="action"
                    onClick={handleClear}
                  />
                  <CalculatorButton
                    id="btn_sign"
                    value="±"
                    label={<span className="font-display text-base text-slate-300 font-medium">±</span>}
                    type="action"
                    onClick={handleToggleSign}
                  />
                  <CalculatorButton
                    id="btn_percent"
                    value="%"
                    label={<Percent className="w-5 h-5 text-slate-300" />}
                    type="action"
                    onClick={handlePercent}
                  />
                  <CalculatorButton
                    id="btn_op_divide"
                    value="÷"
                    label={<span className="text-xl">÷</span>}
                    type="operator"
                    isActive={activeOperation === '÷'}
                    onClick={handleOperator}
                  />

                  {/* Row 2 */}
                  <CalculatorButton
                    id="btn_num_7"
                    value="7"
                    label="7"
                    type="number"
                    onClick={handleNumber}
                  />
                  <CalculatorButton
                    id="btn_num_8"
                    value="8"
                    label="8"
                    type="number"
                    onClick={handleNumber}
                  />
                  <CalculatorButton
                    id="btn_num_9"
                    value="9"
                    label="9"
                    type="number"
                    onClick={handleNumber}
                  />
                  <CalculatorButton
                    id="btn_op_multiply"
                    value="×"
                    label={<span className="text-xl">×</span>}
                    type="operator"
                    isActive={activeOperation === '×'}
                    onClick={handleOperator}
                  />

                  {/* Row 3 */}
                  <CalculatorButton
                    id="btn_num_4"
                    value="4"
                    label="4"
                    type="number"
                    onClick={handleNumber}
                  />
                  <CalculatorButton
                    id="btn_num_5"
                    value="5"
                    label="5"
                    type="number"
                    onClick={handleNumber}
                  />
                  <CalculatorButton
                    id="btn_num_6"
                    value="6"
                    label="6"
                    type="number"
                    onClick={handleNumber}
                  />
                  <CalculatorButton
                    id="btn_op_subtract"
                    value="-"
                    label={<span className="text-xl">−</span>}
                    type="operator"
                    isActive={activeOperation === '-'}
                    onClick={handleOperator}
                  />

                  {/* Row 4 */}
                  <CalculatorButton
                    id="btn_num_1"
                    value="1"
                    label="1"
                    type="number"
                    onClick={handleNumber}
                  />
                  <CalculatorButton
                    id="btn_num_2"
                    value="2"
                    label="2"
                    type="number"
                    onClick={handleNumber}
                  />
                  <CalculatorButton
                    id="btn_num_3"
                    value="3"
                    label="3"
                    type="number"
                    onClick={handleNumber}
                  />
                  <CalculatorButton
                    id="btn_op_add"
                    value="+"
                    label={<span className="text-xl">+</span>}
                    type="operator"
                    isActive={activeOperation === '+'}
                    onClick={handleOperator}
                  />

                  {/* Row 5 */}
                  <CalculatorButton
                    id="btn_num_0"
                    value="0"
                    label="0"
                    type="number"
                    className="col-span-1"
                    onClick={handleNumber}
                  />
                  <CalculatorButton
                    id="btn_decimal"
                    value="."
                    label="."
                    type="number"
                    onClick={handleNumber}
                  />
                  <CalculatorButton
                    id="btn_backspace"
                    value="delete"
                    label={<Delete className="w-5 h-5 text-slate-300" />}
                    type="action"
                    onClick={handleBackspace}
                  />
                  <CalculatorButton
                    id="btn_equals"
                    value="="
                    label={<span className="text-xl">=</span>}
                    type="equals"
                    onClick={handleEqual}
                  />
                </motion.div>
              ) : (
                /* Toggleable Slide-In History Panel */
                <motion.div
                  key="calculator-history"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 15 }}
                  transition={{ duration: 0.2 }}
                  className="absolute inset-0 bg-slate-950/80 backdrop-blur-md rounded-2xl p-4 flex flex-col justify-between border border-slate-800/50"
                >
                  <div className="flex flex-col gap-2 overflow-y-auto max-h-[290px] sm:max-h-[300px] pr-1">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-display font-medium text-xs tracking-wider text-slate-400">RIWAYAT PERHITUNGAN</span>
                      {history.length > 0 && (
                        <button
                          id="btn_clear_history"
                          type="button"
                          onClick={() => {
                            playClickSound(300, 'square', 0.1);
                            setHistory([]);
                          }}
                          className="text-xs text-rose-400 hover:text-rose-300 font-medium hover:underline flex items-center gap-1 cursor-pointer"
                        >
                          Hapus Semua
                        </button>
                      )}
                    </div>

                    {history.length === 0 ? (
                      <div className="flex flex-col items-center justify-center py-12 text-slate-500 gap-2">
                        <History className="w-8 h-8 opacity-40 shrink-0" />
                        <p className="text-xs text-center font-sans">Belum ada riwayat perhitungan</p>
                      </div>
                    ) : (
                      <div className="flex flex-col gap-3">
                        {history.map((item) => (
                          <div 
                            key={item.id} 
                            className="bg-slate-900/80 active:bg-slate-850 p-2.5 rounded-xl border border-slate-800/50 flex flex-col gap-1 items-end hover:border-slate-700/50 transition-colors cursor-pointer"
                            onClick={() => {
                              playClickSound(600, 'sine', 0.04);
                              setCurrentInput(item.result);
                              setEquation(`${item.equation} =`);
                              setIsCalculated(true);
                              setShowHistory(false);
                            }}
                          >
                            <span className="text-slate-500 text-xs font-mono tracking-normal block text-right truncate w-full">
                              {item.equation}
                            </span>
                            <span className="text-indigo-300 text-sm font-semibold font-display tracking-wide block">
                              = {item.result}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Close button inside panel */}
                  <button
                    id="btn_close_history"
                    type="button"
                    onClick={() => {
                      playClickSound(600, 'sine', 0.03);
                      setShowHistory(false);
                    }}
                    className="w-full mt-2 py-2 bg-slate-800 hover:bg-slate-750 text-slate-200 rounded-xl text-xs font-medium font-sans tracking-wide transition-colors cursor-pointer text-center"
                  >
                    Kembali Ke Kalkulator
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

        </div>
      </div>

      {/* Guide Card / Info section below layout with precise negative space spacing */}
      <div className="mt-8 max-w-sm w-full bg-slate-900/30 border border-slate-800/40 rounded-2xl p-4 text-center">
        <p className="text-slate-400 text-xs leading-relaxed font-sans flex items-center justify-center gap-1.5">
          <HelpCircle className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
          <span>Mendukung input keyboard: angka <kbd className="px-1.5 py-0.5 bg-slate-800 border border-slate-700 rounded text-slate-300 font-mono">0-9</kbd>, operator <kbd className="px-1.5 py-0.5 bg-slate-800 border border-slate-700 rounded text-slate-300 font-mono">+</kbd> <kbd className="px-1.5 py-0.5 bg-slate-800 border border-slate-700 rounded text-slate-300 font-mono">-</kbd> <kbd className="px-1.5 py-0.5 bg-slate-800 border border-slate-700 rounded text-slate-300 font-mono">*</kbd> <kbd className="px-1.5 py-0.5 bg-slate-800 border border-slate-700 rounded text-slate-300 font-mono">/</kbd>, <kbd className="px-1.5 py-0.5 bg-slate-800 border border-slate-700 rounded text-slate-300 font-mono">Enter</kbd> (hasil), dan <kbd className="px-1.5 py-0.5 bg-slate-800 border border-slate-700 rounded text-slate-300 font-mono">Caps ESC (Reset)</kbd></span>
        </p>
      </div>

    </div>
  );
};
